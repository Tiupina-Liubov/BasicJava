import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        //1 Дана длина в метрах. Напишите программу, которая переводит указанное
        // значение в км, мили, футы и аршины. Выведите начальное и конвертированные значения на экран.
        Random random = new Random();
        System.out.println();
        int metre = random.nextInt(10000);
        System.out.println("Нам дано " + metre + " м ");
        double km = (metre * 1.0) / 1000;
        System.out.println("Это будет " + km + " км");
        double ml = (double) metre / 1609;
        System.out.println("Это будет " + ml + " миль ");
        double fut = metre * 3.281;
        System.out.println("Это будет " + fut + " футов ");
        double arschn = metre * 1.40607424071991;
        System.out.println("Это будет " + arschn + " аршинов ");
        System.out.println();


        Scanner scanner = new Scanner(System.in);
        System.out.println("Ведите число в метрах - ");
        int metre1 = scanner.nextInt();
        double km1 = (metre1 * 1.0) / 1000;
        System.out.println("Это будет " + km1 + " км");
        double ml1 =  (double) metre1 / 1609;
        System.out.println("Это будет " + ml1 + " миль ");
        double fut1 = metre1 * 3.281;
        System.out.println("Это будет " + fut1 + " футов ");
        double arschn1 = metre1 * 1.40607424071991;
        System.out.println("Это будет " + arschn1 + " аршинов ");
        System.out.println("___________________-");


        //2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель. Выведите сумму сдачи в виде “X рублей и Y копеек”.
        System.out.print("Ведите суму покупки - ");
        float bag = scanner.nextFloat();
        System.out.print("Ведите сколько дал денег покупатель - ");
        float payment = scanner.nextFloat();
        System.out.print("Cдача - ");
        int dolar = (int) (payment - bag);
        int cent = (int) (((payment-bag)/1.0- dolar)*100);
        System.out.println(dolar + " рублей " + cent + " копеек");
        System.out.println("_________________");

        //3 Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather),
        // то ребята пойдут в поход. Если туркружок закупит дождевики (hasBoughtRaincoats)
        // к концу учебного года, то ребята пойдут в поход даже в плохую погоду.
        // В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится от сдачи
        // тренерского экзамена (isJimFree), или тренер Кейт, если она вернётся из путешествия
        // (hasKateComeBack). Вести детей может только один тренер. Если Джим и Кейт смогут вести детей
        // вместе, то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
        //Напишите логическое выражение для вычисления того, состоится ли поход. Подберите условия,
        // при которых поход состоится.
        boolean isYearFinished = true;
        boolean isGoodWeather = true;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean compaignHappy = ((isYearFinished && isGoodWeather) || (isYearFinished && !isGoodWeather && hasBoughtRaincoats) && (isJimFree ^ hasKateComeBack));
        System.out.println(compaignHappy);
        System.out.println("__________________");
        //4 Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и
        // выводит результат. Остаток деления можно отбросить. Операторы деления / и остатка от
        // деления % применять нельзя.
        System.out.println("Ведите целое число которое хотите поделить - ");
        int num1 = scanner.nextInt();
        System.out.println(num1 >> 1);
        System.out.println("__________________");

    }
}
