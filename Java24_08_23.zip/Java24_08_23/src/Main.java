import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: Методы
        //Задание 1.
        //Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
        // В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
        // В методе умножения 4-х чисел – вызов метода для 3-х чисел.
        Random random = new Random();
        int num1 = random.nextInt(-10, 11);
        System.out.println(num1);
        int num2 = random.nextInt(-10, 11);
        System.out.println(num2);
        int multi2 = getMultiplyNumbers(num1, num2);
        System.out.println("Результат умножения 2 чисел = " + multi2);
        int num3 = random.nextInt(0, 1);
        System.out.println("Умножаем 3 рандомных числа " + num1 + "," + num2 + "," + num3);
        int multi3 = getMultiplyNumbers(num1, num2, num3);
        System.out.println("Результат умножения 3 чисел = " + multi3);
        int num4 = random.nextInt(-10, 11);
        System.out.println("Умножаем 4 рандомных числа " + num1 + "," + num2 + "," + num3 + "," + num4);
        int multi4 = getMultiplyNumbers(num1, num2, num3, num4);
        System.out.println("Результат умножения 4 чисел = " + multi4);
        System.out.println();
        //Задание 2.
        //Используя рекурсию, написать метод вычисления факториала числа n (n!), вводимого с клавиатуры.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число для нахождения факториала числа");
        int num = scanner.nextInt();
        int factorial = getfactorial(num);
        System.out.println(factorial);


        //Задание 1.
        //Создайте массив из 8 случайных целых чисел из интервала [1;50]
        //Выведите массив на консоль в строку.
        //Замените каждый элемент с нечетным индексом на ноль.
        //Снова выведете массив на консоль в отдельной строке.
        //Отсортируйте массив по возрастанию.
        //Снова выведете массив на консоль в отдельной строке.
        int[] numbers = new int[8];
        int a = random.nextInt(1, 50);
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = a;
            a = random.nextInt(0, 50);
        }
        System.out.println(Arrays.toString(numbers));
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 != 0) {
                numbers[i] = 0;
            }
        }
        System.out.println(Arrays.toString(numbers));
        Arrays.sort(numbers);
        System.out.println(Arrays.toString(numbers));
        System.out.println();


        //Задание 2.
        //
        //Создайте массив из 5 строк. Используя метод length() строк, найдите строку с наибольшей длиной и строк с наименьшей длиной.
        //Выведите массив и полученный строки в консоль. System.out.println("Hello world!");
        String[] strings = {"Hallo", "How are you", "Where are you?", "What do you like?", "So long"};
        System.out.println(Arrays.toString(strings));
        String minStr = findTheSmallestStr(strings);
        String maxStr = findTheLengthStr(strings);
        System.out.println("Строка с наибольшей длиной - " + maxStr);
        System.out.println("Строка с наименьшей длиной - " + minStr);
        System.out.println();
    }

    public static int getMultiplyNumbers(int num1, int num2) {
        if ((num2 | num1) == 0) {
            System.out.println("Одно из чисел являиться 0 Потому резултьтат умножения будет равен '0'");
            return 0;
        }
        return num1 * num2;
    }

    public static int getMultiplyNumbers(int num1, int num2, int num3) {
        if (num3 == 0) {
            System.out.println("Одно из чисел являиться 0 Потому резултьтат умножения будет равен '0'");
            return 0;
        }
        return getMultiplyNumbers(num1, num2) * num3;
    }

    public static int getMultiplyNumbers(int num1, int num2, int num3, int num4) {
        if (num4 == 0) {
            System.out.println("Одно из чисел являиться 0 Потому резултьтат умножения будет равен '0'");
            return 0;
        }
        return getMultiplyNumbers(num1, num2, num3) * num4;
    }

    private static String findTheLengthStr(String[] strings) {
        int a = 0;
        String max = null;
        String maxSt = "0";
        for (int i = 0; i < strings.length; i++) {
            String str = String.valueOf(strings[i].length());
            if (maxSt.length() <= str.length()) {
                maxSt = str;
                a = i;
                max = strings[Integer.valueOf(a)];
                continue;
            }
        }
        return max;
    }

    private static String findTheSmallestStr(String[] strings) {
        int a = 0;
        String min = null;
        String maxSt = findTheLengthStr(strings);
        for (int i = 0; i < strings.length; i++) {
            String minim = String.valueOf(strings[i].length());
            if (maxSt.length() > minim.length()) {
                maxSt = minim;
                a = i;
                min = strings[Integer.valueOf(a)];
                continue;
            }
        }
        return min;
    }

    private static int getfactorial(int numUser) {
        int fact = 1;
        if (numUser < 0) {
            System.out.println("Зачем тебе факториал из отрицательного числа?");
            return Integer.parseInt(null);
        }
        if (numUser == 0) {
            return fact;
        }
        for (int i = 1; i <= numUser; i++) {
            fact = numUser * getfactorial(numUser - 1);
        }
        return fact;
    }

}

