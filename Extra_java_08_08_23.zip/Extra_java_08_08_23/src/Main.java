import java.util.Random;

public class Main {
    public static void main(String[] args) {
        System.out.println();
        Random random = new Random();
        double a = Math.random()/ Math.nextDown(0.100);
        double b = Math.random()/ Math.nextDown(10);
        System.out.println(a);
        System.out.println(b);
        double abs = Math.abs(a - b);
        double min = Math.min(a, b);
        double max = Math.max(a,b);
        double pow = Math.pow(a, b*10);
        System.out.println(abs);
        System.out.println(min);
        System.out.println(max);
        System.out.println(pow);



    }
}