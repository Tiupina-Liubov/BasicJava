import java.time.DayOfWeek;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] rgs) {

        //1 Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
        //Например :
        //ввод : m=10.5, n=10.45
        //вывод: Число 10.45 ближе к 10.
        Random random = new Random();
        int m = random.nextInt(-200, 201);
        float n = random.nextFloat(-200, 201);
        int nul = 10;
        boolean minM = m < 0;
        boolean minN = n < 0.0F;
        boolean pozN = n > 0.0F;
        boolean pozM = m > 0;
        System.out.println("Дано 2 числа: " + m + " и " + n);
        System.out.println(" Какое число ближе к 10? ");
        if (minN && minM) {
            if (m - nul > n - nul) {
                System.out.println("Число " + m + " ближе к 10");
            } else {
                System.out.println("Число " + n + " ближе к 10");
            }
        }
        if (pozM && pozN) {
            if (m - nul > n - nul) {
                System.out.println("Число " + n + " ближе к 10");
            } else {
                System.out.println("Число " + m + " ближе к 10");
            }
        }
        if (pozM & minN) {
            if(m>-n){
                if (m - nul > n - nul ){
                System.out.println("Число " + n + " ближе к 10");
            }
        }
            if (m<=-n){
                if (m - nul > n - nul ){
                    System.out.println("Число " + m + " ближе к 10");
                }
            }
        }
        if (pozN & minM) {
            if(n>-m){
                if (m - nul < n - nul ){
                    System.out.println("Число " + m + " ближе к 10");
                }
            }
            if (n<=-m){
                if (m - nul < n - nul ){
                    System.out.println("Число " + n + " ближе к 10");
                }
            }
        }
        //2 Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
        // Пользователь сам вводит два целых однозначных числа. Программа задаёт вопрос: результат
        // умножения первого числа на второе.  Пользователь должен ввести ответ и увидеть на экране
        // правильно он ответил или нет. Если пользователь ответил неправильно, то программа должна
        // показать правильный ответ.
        System.out.println("Проверка таблицы умножения");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите первое число - ");
        int num1 = scanner.nextInt();
        System.out.print("Введите второе число - ");
        int num2 = scanner.nextInt();
        System.out.print("Pезультат умножения первого числа на второе - ");
        int answer = scanner.nextInt();
        int mult = num1 * num2;
        if (answer == mult) {
            System.out.println("Ты молодец!");
        } else {
            System.out.println("Учись усердней. Правильный ответ будет - " + mult);
        }
        //3 Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы, напишите программу,
        // в которой пользователь вводит год. Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
        // Если указанный пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!».
        // Если введённый пользователем год больше 1977, то вывести «Элвис навсегда в наших сердцах!»
        System.out.print("Введите год жизни Элвиса - ");
        int year = scanner.nextInt();
        System.out.println(year < 1935 ? "Элвис ещё не родился" : "");
        System.out.println(year > 1977 ? "Элвис навсегда в наших сердцах!" : "");
        System.out.println((year >= 1935) && year <= 1977 ? "Элвис жив!" : "");

        //Дополнительная практика
        // Дан (введён или сгенерирован) номер дня недели. Выведите название дня недели.
        // Если номер дня введён некорректно, то выведите соответствующее сообщение и завершите программу.
        int numDay = random.nextInt(10);
        System.out.println("Как называется день недели под номером " + numDay);
        String nameDay1 = DayOfWeek.MONDAY.name();
        String nameDay2 = DayOfWeek.THURSDAY.name();
        String nameDay3 = DayOfWeek.WEDNESDAY.name();
        String nameDay4 = DayOfWeek.TUESDAY.name();
        String nameDay5 = DayOfWeek.FRIDAY.name();
        String nameDay6 = DayOfWeek.SATURDAY.name();
        String nameDay7 = DayOfWeek.SUNDAY.name();
        if (numDay == 1) {
            System.out.println(nameDay1);
        }
        if (numDay == 2) {
            System.out.println(nameDay2);
        }
        if (numDay == 3) {
            System.out.println(nameDay3);
        }
        if (numDay == 4) {
            System.out.println(nameDay4);
        }
        if (numDay == 5) {
            System.out.println(nameDay5);
        }
        if (numDay == 6) {
            System.out.println(nameDay6);
        }
        if (numDay == 7) {
            System.out.println(nameDay7);
        }
        if (numDay > 7 ^ numDay == 0) {
            System.out.println("Это неизвестный день недели!:(");
        }
    }
}
