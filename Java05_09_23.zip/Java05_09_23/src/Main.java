import Animal.Animal;
import Animal.AnimalSpecies;
import Animal.VeterinaryClinic;

import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //1 Создайте Package (ПКМ на папке src -> New -> Package).
        //1.1 В созданном пакете создайте класс с минимум 3мя полями для одного из объектов реального
        // мира (студент, батарейка, автомобиль...). Одно из полей сделайте публичным, второе –
        // без модификатора доступа, остальные – приватными. Создайте объект этого класса в программе
        // и попробуйте установить значения для полей. Какие поля возможно установить?
        //1.2 Создайте второй класс в том же пакете, в котором будет создаваться первый класс
        // (например, класс Университет для класса Студент или класс Завод для класса автомобиль).
        // Внутри класса определите метод, который создаёт объект первого класса и присвоите ему те
        // поля, которые возможно. Какие поля возможно задать?
        //1.3 Напишите минимум 2 конструктора для класса 1.
        //1.4 Реализуйте геттеры и сеттеры для класса 1.
        //1.5 Создайте другие методы для класса.
        //1.6 Создайте класс 3 и добавьте поле типа класса 3 в класс 2. При создании объекта класса
        // 1 заполните новое поле.
        //1.7 Добавьте клонирующий конструктор к классу 1. В программе склонируйте созданный
        // ранее объект. Проверьте с помощью ==, что объекты имеют разные ссылки в памяти.
        // Затем измените объект класса 3, который лежит внутри оригинального объекта класса 1.
        // 8 С помощью == сравните ссылочные поля оригинала и клона. Вложенные объекты имеют
        // одинаковую ссылку в памяти?
        Animal cat = new Animal();
        //Можно установить только публичные поля. Все остальные не видны без
        // гетееров и сетторов.
        cat.setAge(LocalDate.of(2021, 10, 26));
        cat.setId(1234567891222L);
        cat.setName("Musa");
        cat.setWeight(10.5f);
        cat.setBreed("Metis");
        Animal cat1 = new Animal(cat);
        boolean b = cat == cat1;
        System.out.println(b);
        System.out.println(cat.equals(cat1));
        System.out.println(cat.may());
        Animal[]cats = new Animal[10];
        System.out.println(VeterinaryClinic.recovering(cat));
        System.out.println(VeterinaryClinic.addAnimal(cats,cat));
        System.out.println(Arrays.toString(cats));
        VeterinaryClinic.addAnimal(cats,cat1);
        System.out.println(Arrays.toString(cats));
        VeterinaryClinic.removeAnimal(cats,cat);
        System.out.println(Arrays.toString(cats));
        System.out.println(cat.medicationsTaken(cat));






    }
}