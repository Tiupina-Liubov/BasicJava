package Animal;

import java.time.LocalDate;

public class Animal {
    //1 Создайте Package (ПКМ на папке src -> New -> Package).
    //1.1 В созданном пакете создайте класс с минимум 3мя полями для одного из объектов реального
    // мира (студент, батарейка, автомобиль...). Одно из полей сделайте публичным, второе – без
    // модификатора доступа, остальные – приватными. Создайте объект этого класса в программе и
    // попробуйте установить значения для полей. Какие поля возможно установить?
    public AnimalSpecies animalSpecies;
    public String name;
    long id;
    private String breed;
    private LocalDate age;
    private float weight;
    private String hostName;

    //1.3 Напишите минимум 2 конструктора для класса 1.
    public Animal(AnimalSpecies animalSpecies) {
        this.animalSpecies = animalSpecies;
    }

    public Animal(AnimalSpecies animalSpecies, String hostName) {
        this(animalSpecies);
        this.hostName = hostName;
    }

    public Animal(Animal original) {
        this(original.animalSpecies, original.name);
        this.hostName = original.hostName;
        this.id = original.id;
        this.age = original.age;
        this.weight = original.weight;
        this.breed = original.breed;
    }

    public Animal() {

    }

    //1.4 Реализуйте геттеры и сеттеры для класса 1.
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null) {
            throw new NullPointerException("Имя не может быть null");
        }
        this.name = name;
    }

    public long getId() {

        return id;
    }

    public void setId(long id) {

        this.id = id;
    }

    public String getBreed() {

        return breed;
    }

    public void setBreed(String breed) {

        this.breed = breed;
    }

    public LocalDate getAge() {
        return age;
    }

    public void setAge(LocalDate age) {

        this.age = age;
    }

    public float getWeight() {

        return weight;
    }

    public void setWeight(float weight) {

        this.weight = weight;
    }

    //1.5 Создайте другие методы для класса.
    public static String may() {
        return "May! May!";
    }

    public static String medicationsTaken(Animal animal) {

        return animal.name + " принял все лекарства! ";
    }

}
