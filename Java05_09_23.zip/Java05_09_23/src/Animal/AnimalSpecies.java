package Animal;

public enum AnimalSpecies {
    CAT,
    DOG,
    BIRD,
    RODENT,
    AMPHIBIAN,
    FISH,
    MONKEY,

}
