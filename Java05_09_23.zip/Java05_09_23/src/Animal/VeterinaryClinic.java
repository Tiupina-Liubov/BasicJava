package Animal;
//1.2 Создайте второй класс в том же пакете, в котором будет создаваться первый класс
// (например, класс Университет для класса Студент или класс Завод для класса автомобиль).
// Внутри класса определите метод, который создаёт объект первого класса и присвоите ему те поля,
// которые возможно. Какие поля возможно задать?
public class VeterinaryClinic {
    private Animal[] animals;
    public static String recovering(Animal cat){
       return "Уже поправился";
    }
    Animal cat = new Animal();
Animal [] animalCat=new Animal[10];
    public static Animal[] addAnimal(Animal[] animals, Animal cat) {
        for (int i = 0; i < animals.length; i++) {
            if (animals[i] == null) {
                animals[i] = cat;
                return animals;
            }
        }
        return animals;
    }
    public static Animal[] removeAnimal(Animal[] animals, Animal cat) {
        for (int i = 0; i < animals.length; i++) {
            if (animals[i]==cat) {
                animals[i] = null;
                return animals;
            }
        }
        return animals;
    }


        


    }


