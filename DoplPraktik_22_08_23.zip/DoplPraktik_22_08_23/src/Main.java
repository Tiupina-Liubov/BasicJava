import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

       //Напишите программу, моделирующую работу табло при ожидании лифта.
        //В здании 35 этажей. Лифт находится на произвольном этаже в диапазоне от 0 до 35
        // (выбирается случайно). Пользователь нажимает кнопку вызова лифта (вводит на каком
        // этаже он находится). После этого лифт начинает движение. Пользователь может видеть,
        // как лифт движется по этажам (программа должна выводить каждый этаж лифта,
        // когда лифт движется).
        Random random= new Random();
        int liftPosi = random.nextInt(0,36);
        System.out.println("Лифт находиться на "+liftPosi+ " этаже");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите на каком этаже вы находитесь - ");
        int HumanPosi = scanner.nextInt();
        for (int i = liftPosi; i <HumanPosi ; i++) {
            System.out.println(i+1);
        }
        for (int i = liftPosi; i >HumanPosi; i--) {
            System.out.println(i-1);
        }
        System.out.println("Лифт прибил");
    }
}