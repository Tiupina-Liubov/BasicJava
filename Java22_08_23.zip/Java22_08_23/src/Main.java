

import java.time.DayOfWeek;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //1 уровень сложности: Задание 1
        //Напиши программу, которая моделирует ситуацию.
        //Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
        // Каждый друг случайным образом может подарить тебе одну купюру номиналом
        // 50, 100, 200 или 500 долларов. Твоя цель - новенький игровой компьютер,
        // который стоит 10 000 долларов.
        //Как только друзья подарят тебе нужную сумму (или даже чуть больше), останавливай сбор
        // подарков и веди всех выпить за твоё здоровье в лучший бар города!
        Random random = new Random();

        System.out.println("Сбор денег на новый ноутбук");
        int sum = 0;
        while (sum <= 10000) {
            int moneyOfFrens = random.nextInt(0,4);
            int money = switch (moneyOfFrens) {
                case 0 -> 50;
                case 1 -> 100;
                case 2 -> 200;
                case 3 -> 500;
                default -> 0;
            };
            System.out.println(money);
            sum = money + sum;
        } System.out.println("Вы собрали нужную суму " + sum + " Теперь можно и выпеть");


        //Задание 2
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.
        //Необходимо суммировать все нечётные целые числа в диапазоне,
        // введённом пользователем. Программу повторять,
        // пока пользователь не введёт «quit».
        System.out.println("Вычисление сумы всех нечетных чисел от 0 до заданого числа."+
                "Для того чтобы выйти напишите слова QUIT.");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число 1 - ");
        int suma = 0;
        do {
            String exit = scanner.nextLine();

            if (exit.equalsIgnoreCase("quit")) {
                break;
            }
            int nomberUser = Integer.parseInt(exit);
            suma = 0;
            for (int i = 1; i <= nomberUser; i++) {
                suma += i;
            }
            System.out.println("Suma " + suma);
            System.out.print("Введите новое число - ");
        } while (true);
        System.out.println("Программа окончена. Удачи!");

        //Задание 3
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
        // Программа должна вывести все дни недели, кроме данного.
        System.out.println("Введите день недели - ");
        String day = scanner.nextLine();
        DayOfWeek userDay = DayOfWeek.valueOf(day.toUpperCase(Locale.ROOT));

        for ( java.time.DayOfWeek a :DayOfWeek.values()){
            if (a==userDay){
                continue;
            }
            System.out.println(a);
        }
            System.out.println();
    }
}