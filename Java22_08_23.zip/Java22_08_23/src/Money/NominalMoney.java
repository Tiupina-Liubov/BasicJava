package Money;

public enum NominalMoney {
    FIFTI,
    ONE_HUNDRED,
    TWO_HUNDRED,
    FIVE_HUNDRED

}
