import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: Двумерные массивы
        //Создайте двумерный массив и заполните его заглавными буквами русского алфавита.
        // Буква Ё должна быть на своём месте.
        char[][] alphabet = new char[6][6];
        char letter= 'А';
        for (char i = 0; i < alphabet.length; i++) {
            for (char j = 0; j < alphabet[i].length; j++) {
                if (letter == 'Ж'){
                    letter= 'Ё';
                }
                alphabet[i][j] = letter;
                if (letter == 'Ђ') {
                    letter = 'Ж';
                }
                alphabet[i][j] = letter;
                letter++;
                if(letter=='Я'+1){
                    break;
                }
            }
        }
        System.out.println(Arrays.deepToString(alphabet));

        //Строк
        //№1
        //Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв
        // (проверьте количество букв в слове).
        //Нужно получить слово, состоящее из первой половины первого слова и второй половины
        // второго слова. распечатать на консоль.
        //Например:
        //ввод - mama, papa
        //вывод - mapa
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите 1 слово с четным количеством букв - ");
        String word1 = scanner.nextLine();
        while ((word1.length() % 2) != 0) {
            System.out.print("Введите слово из четного количества букв - ");
            word1 = scanner.nextLine();
            continue;
        }
        System.out.print("Введите 2 слово с четным количеством букв - ");
        String word2 = scanner.nextLine();
        while ((word2.length() % 2) != 0) {
            System.out.print("Введите слово из четного количества букв - ");
            word2 = scanner.nextLine();
            continue;
        }
        System.out.println(word1.substring(0, word1.length() / 2) + (word2.substring(word2.length() / 2, word2.length())));

        //№ 2
        //Создайте строку через new - I study Basic Java!
        //Напишите метод, который принимает в качестве параметра строку,
        // передайте в этот метод строку, которую создали в п.1
        //Распечатать последний символ строки. Используем метод String.charAt().
        //Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
        //Заменить все символы “а” на “о”.
        //Преобразуйте строку к верхнему регистру.
        //Преобразуйте строку к нижнему регистру.
        //Вырезать строку Java c помощью метода String.substring().
        String str = new String("I study Basic Java!");
        System.out.println(str.charAt(str.length() - 1));
        System.out.println(str.contains("Java"));
        System.out.println(str.replace("a", "o"));
        System.out.println(str.toUpperCase(Locale.ROOT));
        System.out.println(str.toLowerCase(Locale.ROOT));
        System.out.println(str.substring(14, str.length() - 1));


        //№ 3
        //Задание из собеседования Яндекс:
        //дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
        // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв
        // записывается цифрой. Если буква одна, то цифра не ставится.
        String string ="AAAAABBBBCCDEEEEEFFFFGGHLLLLMMMNNN";
        System.out.println(letterСount(string));


    }
    public static String letterСount (String str)
    {
        if (str == null || str.equals(""))
        {
            return str;
        }
        char curentChar = str.charAt(0);
        int curentCharCount = 1;
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= str.length(); i++)
        {
            char c = (i < str.length() ? str.charAt(i) : 0);
            if (i == str.length() || curentCharCount == str.length() || c != curentChar)
            {
                sb.append(curentChar);
                if (curentCharCount > 1)
                {
                    sb.append((char)(curentCharCount + '0'));
                }
                curentCharCount = 1;
                curentChar = c;
            }
            else
            {
                curentCharCount++;
            }
        }
        return sb.toString();
}
}



