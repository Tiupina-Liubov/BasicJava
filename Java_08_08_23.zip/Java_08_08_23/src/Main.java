import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        System.out.println("1.1");//Напишите программу, в которой объявите переменные всех примитивных типов. Значение для каждой переменной сгенерируйте с помощью класса Random.
        // При необходимости используйте приведение типов. Полученные значения выведите в консоль.
        Random random = new Random();
        byte myByte;
        int myInt;
        long myLong;
        char myChar;
        double myDouble;
        boolean myBoolean;
        float myFloat;
        myInt = random.nextInt(100);
        System.out.println(myInt);
        myChar = (char) random.nextInt();
        System.out.println(myChar);
        myByte = (byte) random.nextInt();
        System.out.println(myByte);
        myBoolean = random.nextBoolean();
        System.out.println(myBoolean);
        myFloat = random.nextFloat(10);
        System.out.println(myFloat);
        myLong = random.nextLong(1000);
        System.out.println(myLong);
        myDouble = random.nextDouble();
        System.out.println(myDouble);
        System.out.println("_________________________");

        System.out.println("1.2");//В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
        // При необходимости используйте метод String.valueOf(). Ограничений на длину строки и содержимое нет. Полученное значение выведите в консоль.
        String string = UUID.randomUUID().toString();
        System.out.println(string);
        String string1 = String.valueOf((myLong + myInt) + "Privet" + myByte);
        System.out.println(string1);
        System.out.println("_________________________");
        System.out.println("2");//Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
        // Когда все данные введены, программа должна выдать сообщение: «Уважаемый, [Имя]!
        // В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
        // В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите ваше имя: ");
        String name = scanner.nextLine();
        System.out.println("Сколько вам лет: ");
        String age = scanner.nextLine();
        System.out.print("Введите свой вес: ");
        String weight = scanner.nextLine();
        System.out.println("Уважаемый," + name + " В свои " + age + "лет Вы для нас дороги, как " + weight + " килограмм золота.»");
        System.out.println("__________________________");
        System.out.println("3");//Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму (сложение),
        // разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел. Результат вычислений выведите в консоль.

        System.out.print("Введите первое число  ");
        int num1 = scanner.nextInt();
        System.out.print("Введите вторе число  ");
        int num2 = scanner.nextInt();
        System.out.println("Разница = " + (num1 - num2));
        System.out.println("Произведение = " + (num1 * num2));
        System.out.println("Частное = " + ((float) num1 * 1.0 / num2));
        System.out.println("Сумму = " + (num1 + num2));
        


    }
}
