import java.time.LocalDate;
import java.util.Arrays;


public class Main {

    public static void main(String[] args) {
        //1 Создайте массив из 8 элементов. В массиве должны
        // храниться даты (класс LocalDate).
        // Чтобы создать элемент LocalDate используйте
        // метод LocalDate.of(год, месяц, день), где год, месяц
        // и день – целые числа.
        //Выведите массив в консоль.
        //2 Напишите метод, который отсортирует массив дат по году.
        // Выведите массив в консоль.
        //3 Напишите метод, который отсортирует массив дат по дню
        // месяца. Выведите массив в консоль.
        //Сортировку можно выполнить по любому из изученных алгоритмов.
        System.out.println();
        LocalDate date = LocalDate.of(1993, 8, 4);


        LocalDate[] dates = {
                LocalDate.of(1993, 7, 3),
                LocalDate.of(1993, 9, 9),
                LocalDate.of(1709, 12, 30),
                LocalDate.of(1993, 1, 21),
                LocalDate.of(1990, 8, 15),
                LocalDate.of(1993, 6, 6),
                LocalDate.of(2007, 7, 2),
                LocalDate.of(1976, 3, 12),
        };
        System.out.println(Arrays.toString(dates));
        sortYear(dates);
        System.out.println(Arrays.toString(dates));
        sortDay(dates);
        System.out.println(Arrays.toString(dates));


    }
    private static void swapValues(LocalDate[] dates, int a, int b) {
        LocalDate temp = dates[a];
        dates[a] = dates[b];
        dates[b] = temp;

    }

    public static void sortYear(LocalDate[] dates) {
        boolean isSorted = false;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < dates.length - 1; i++) {
                if (dates[i].getYear() > dates[i + 1].getYear()) {
                    swapValues(dates, i, i + 1);
                    isSorted = false;
                }
            }
        }
    }
    public static void sortDay(LocalDate[] dates) {
        boolean isSorted = false;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < dates.length - 1; i++) {
                if (dates[i].getDayOfMonth() > dates[i + 1].getDayOfMonth()) {

                    swapValues(dates, i, i + 1);
                    isSorted = false;
                }
            }
        }
    }
}