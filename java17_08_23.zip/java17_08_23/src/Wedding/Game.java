package Wedding;

public enum Game
{
}
