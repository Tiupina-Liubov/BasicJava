package Wedding;

public enum Game {
    SCISSORS,
    PAPER,
    STONE
}
