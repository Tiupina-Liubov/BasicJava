package Wedding;

public enum WeddingAnniversary {
    GREEN,
    GAUZE,
    PUILP,
    LEATHER,
    WOODEN,
    CAST_IRON,
    COPPER,
    TIN,
    FAIENCE,
    STANNIC,
    STEEL,
    NICKEL,
    LACY,
    AGATE,
    CRYSTAL,
    TOPAZ,
    ROZE,
    TURQUOISE,
    POMEGRANATE,
    PORCELAIN,
    OPAL,
    BRONZE,
    BERYL,
    SATIN,
    SILVER
    







}
