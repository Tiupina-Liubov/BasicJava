package Wedding;

public enum Months {
    JANUARY,
    FEBRUARY,
    MARCH,
    APRIL,
    MAI,
    JUNE,
    JULI,
    AUGUST,
    SEPTEMBER,
    OCTOBER,
    NOVEMBER,
    DECEMBER
}
