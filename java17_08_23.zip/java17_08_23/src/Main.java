import java.util.Random;
import java.util.Scanner;

import Wedding.WeddingAnniversary;

public class Main {
    public static void main(String[] args) {
//Задание 1. Пользователь вводит, сколько лет он состоит в браке.
// Программа должна вывести, какая годовщина свадьбы будет у пользователя
// следующей (бумажная, ситцевая, чугунная, серебряная и.д.).
// Не обязательно указывать все годовщины, достаточно 10-15.
// Узнать про годовщины можно, например, здесь
// https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
        Scanner scanner = new Scanner(System.in);
        System.out.print("Сколько лет вы в браке - ");
        int yearMerry = scanner.nextInt();
        String weddingName = switch (yearMerry) {
            case 0 -> "У вас еще нету годовщины!";
            case 1 -> WeddingAnniversary.GREEN.name();
            case 2 -> WeddingAnniversary.GAUZE.name();
            case 3 -> WeddingAnniversary.PUILP.name();
            case 4 -> WeddingAnniversary.LEATHER.name();
            case 5 -> WeddingAnniversary.WOODEN.name();
            case 6 -> WeddingAnniversary.CAST_IRON.name();
            case 7 -> WeddingAnniversary.COPPER.name();
            case 8 -> WeddingAnniversary.TIN.name();
            case 9 -> WeddingAnniversary.FAIENCE.name();
            case 10 -> WeddingAnniversary.STANNIC.name();
            case 11 -> WeddingAnniversary.STEEL.name();
            case 12 -> WeddingAnniversary.NICKEL.name();
            case 13 -> WeddingAnniversary.LACY.name();
            case 14 -> WeddingAnniversary.AGATE.name();
            case 15 -> WeddingAnniversary.CRYSTAL.name();
            case 16 -> WeddingAnniversary.TOPAZ.name();
            case 17 -> WeddingAnniversary.ROZE.name();
            case 18 -> WeddingAnniversary.TURQUOISE.name();
            case 19 -> WeddingAnniversary.POMEGRANATE.name();
            case 20 -> WeddingAnniversary.PORCELAIN.name();
            case 21 -> WeddingAnniversary.OPAL.name();
            case 22 -> WeddingAnniversary.BRONZE.name();
            case 23 -> WeddingAnniversary.BERYL.name();
            case 24 -> WeddingAnniversary.SATIN.name();
            case 25 -> WeddingAnniversary.SILVER.name();
            default -> "К сожалению я не знаю название этой годовщины!";
        };
        System.out.println(weddingName);
        //2 Напишите консольную игру "Камень, ножницы, бумага". Пользователь вводит свой выбор
        // (в виде строки или числа - выберете что-то одно). Программа случайным образом делает свой выбор
        // и выводит на экран. Далее программа показывает, кто победитель - пользователь или программа.
        Random random = new Random();
        System.out.println("ВВЕДИТЕ ЧТО ХОТИТЕ ИЗ ПРЕДЛОЖЕНЫХ ВАРИАНТОВ, ВВОДИТЕ ТОЛЬКО ЦИФРЫ : КАМЕНЬ = 1 ,НОЖНЕЦИ = 2 ,БУМАГА = 3 - ");
        int choice = scanner.nextInt();
        int choiceComp = random.nextInt(1, 4);
        System.out.println("Ваш соперник выбрал  - " + choiceComp);
        if (choice == choiceComp) {
            System.out.println("Победителя нету вы выбрали одинаково");
        }
        System.out.println(choice + 1 < choiceComp ? "Вы проиграли :( !" : (choice - 1 == choiceComp ? "Вы проиграли :( !" : "Ура! Вы выиграли ;) !16"));
    }
}
