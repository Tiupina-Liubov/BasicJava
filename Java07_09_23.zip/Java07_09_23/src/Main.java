import auto.Auto;
import mathutil.MathUtilt;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        // 1 уровень сложности: №1
        //Создайте утилитарный класс, который будет аналогом класса Math.
        // В нём будет один приватный конструктор, а также только статические методы:
        //addAll - сложение неограниченного числа аргументов
        //minusAll – принимает исходное число и неограниченный набор
        // аргументов, которые нужно вычесть из исходного числа
        //multAll – перемножает все данные аргументы
        //powAll – принимает исходное число-основание и неограниченный
        // набор аргументов степеней. Нужно последовательно возвести
        // основание во все степени.
        //Используйте все методы в коде метода main.
        //
        int a = 3;
        int b = 4;
        int c = 2;
        int d = 54;

        System.out.println(MathUtilt.addAll(a, b, c));
        System.out.println(MathUtilt.minusAll(d, a, b, c));
        System.out.println(MathUtilt.multAll(a, b, c));
        System.out.println(MathUtilt.powAll(a, b, c));

        //№2
        //Напишите класс Автомобиль с минимум пятью полями. Переопределите метод toString,
        // чтобы он выводил полное описание автомобиля по его полям. В программе создайте 3 разных
        // автомобиля и выведите каждый из них в консоль.
        //Создайте массив из этих автомобилей. С помощью Arrays.toString() превратите массив в строку и
        // выведите в консоль.
        //Перейдите в код метода Arrays.toString() и посмотрите на его реализацию. В какой момент автомобиль
        // становится строкой внутри этого метода?
        Auto auto = new Auto("Audi", 10987556L, "Green", 123455.9, 2021);
        Auto auto1 = new Auto("BMW", 1234567L, "Blake", 1234.6, 2020);
        Auto auto2 = new Auto("Mercedes-Benz", 10999956L, "Grey", 123777.9, 2023);
        System.out.println(Auto.toString(auto));
        System.out.println(Auto.toString(auto1));
        System.out.println(Auto.toString(auto2));
        Auto[] autos = {auto, auto1, auto2};
        System.out.println(Arrays.toString(autos));
        System.out.println(auto1.getBrand());
    }
}