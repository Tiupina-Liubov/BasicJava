package mathutil;

public class MathUtilt {
    private MathUtilt() {
    }

    public static int addAll(int... a) {//addAll - сложение неограниченного числа аргументов
        int sum = 0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum;
    }

    public static float addAll(float... a) {//addAll - сложение неограниченного числа аргументов
        float sum = 0.0f;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum;
    }

    public static double addAll(double... a) {//addAll - сложение неограниченного числа аргументов
        double sum = 0.0;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum;
    }

    public static long addAll(long... a) {//addAll - сложение неограниченного числа аргументов
        long sum = 0L;
        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum;
    }

    //minusAll – принимает исходное число и неограниченный набор
    // аргументов, которые нужно вычесть из исходного числа
    public static int minusAll(int a, int... b) {
        for (int i = 0; i < b.length; i++) {
            int min = b[i];
            a -= min;
        }
        return a;
    }

    //multAll – перемножает все данные аргументы
    public static int multAll(int... a) {
        int mult = 1;
        for (int i = 0; i < a.length; i++) {
            mult *= a[i];
        }
        return mult;
    }

    //powAll – принимает исходное число-основание и неограниченный
    // набор аргументов степеней. Нужно последовательно возвести
    // основание во все степени.
    public static int powAll(int a, int... b) {
        int pow = 0;
        for (int i = 0; i < b.length; i++) {
            int stp = b[i];
            pow = (int) Math.pow(a, stp);
            System.out.println(pow);
            if (b[i] == b.length) {
                break;
            }
        }
        return pow;
    }
}
