package auto;

import java.awt.*;
import java.time.LocalDate;

public class Auto {
    //Напишите класс Автомобиль с минимум пятью полями. Переопределите метод toString,
    // чтобы он выводил полное описание автомобиля по его полям. В программе создайте 3 разных
    // автомобиля и выведите каждый из них в консоль.
    //Создайте массив из этих автомобилей. С помощью Arrays.toString() превратите массив в строку и
    // выведите в консоль.
    //Перейдите в код метода Arrays.toString() и посмотрите на его реализацию. В какой момент автомобиль
    // становится строкой внутри этого метода?
    private String brand;
    private long id;
    private String color;
    private double mileage;
    private int yearOfIssue;


    public String getBrand() {
        return brand;
    }

    public long getId() {
        return id;
    }

    public String getColor() {
        return color;
    }

    public double getMileage() {
        return mileage;
    }

    public int getYearOfIssue() {
        return yearOfIssue;
    }

    public Auto(String brand, long id, String color, double mileage, int yearOfIssue) {
        this.brand = brand;
        this.color = color;
        this.id = id;
        this.mileage = mileage;
        this.yearOfIssue = yearOfIssue;
    }

    public static String toString(Auto auto) {
        return (auto.brand + " , " + auto.id + " , " + auto.color + " , " + auto.mileage + " , " + auto.yearOfIssue);

    }
}
