public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        System.out.println("2"+2);/*Просто складывает вместе в одну страку без знаков и полчаем 22*/
        System.out.print("23+23");
        System.out.println("");
        System.out.println("23+23");
        System.out.println("");
        System.out.println("Hi Liubov!");
        System.out.print(2+2);







    }
}