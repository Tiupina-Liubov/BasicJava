
public class Main {
    public static void main(String[] args) {

        System.out.println("Задание №1");
        System.out.println("В методе main создать переменные всех примитивных типов и вывести их значения в консоль:");
        System.out.println("Переменные");
        int a1;
        a1 = 89;
        byte a2;
        a2 = 4;
        char a3;
        a3 = 'G';
        short a4;
        a4 = 56;
        float a5;
        a5 = 4.7333436F;
        double a6;
        a6 = 4.355453532;
        long a7;
        a7 = 12121;
        System.out.println(a1);
        System.out.println(a2);
        System.out.println(a3);
        System.out.println(a4);
        System.out.println(a5);
        System.out.println(a6);
        System.out.println(a7);
        System.out.println("-------------------------------------");
        System.out.println();
        System.out.println();
        System.out.println("Задание №2");
        System.out.println("Дано трехзначное число. Вывести на экран все цифры этого числа.Пример : 345. Вывод в консоль: Число 345 -> 3, 4, 5");
        System.out.println();
        int num = 345;
        int a = 3;
        int b = 4;
        int c = 5;
        System.out.println(num + "->" + a + "," + b + "," + c);
        System.out.println();
        System.out.println("-------------------------------");
        System.out.println("Дополнительная практика");
        System.out.println("1");//"1. Провести исследование: задать переменной максимальное значение для её типа. Вывести значение переменной на экран. Затем добавить 1 к значению переменной и снова вывести значение переменной на экран. Какой результат Вы получили?"//
        System.out.println();
        byte mybyte = 127;/**/
        short myshort = 32767;

        mybyte = (byte) (mybyte + 1);/* (mybyte = mybyte +1;) Если прописывать так, то показывает ошибку или предлагает поменять тип переменой.  */
        System.out.println(mybyte);
        myshort = (short) (myshort + 1);
        System.out.println(myshort);
        System.out.println("2");/* Провести исследование: вывести на экран произведение переменной целого типа и переменной дробного типа. Какой тип получился в результате? Попробуйте поместить результат в переменную.*/

        System.out.println();











    }
}